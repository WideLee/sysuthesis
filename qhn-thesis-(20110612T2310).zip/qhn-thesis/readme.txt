﻿%%
%%************************************************************************
%%
%%  2011 June, by "mxctor"<qiuhuining@gmail.com>
%%
%%  The author disclaims copyright to this source code. In place of
%%  a legal notice, here is a blessing:
%%
%%     May you do good and not evil.
%%     May you find forgiveness for yourself and forgive others.
%%     May you share freely, never taking more than you give.
%%
%%  -- I am saying thanks to all great Minds.
%%
%%************************************************************************
%%

说明：

（1）这是一份博士论文的 LaTeX 全稿的完整打包，在 Windows XP + CTeX 2.9.0 套装下可以顺利编译成功。
（2）论文模板 sysuthesis.cls 由中科院的 CASThesis 模板修改而来，因此是基于 ctexbook 类的定制。
（3）请务必使用 XeLaTeX 进行编译，并且建议所有文档都存为 UTF-8 格式，并在每个文档开头第一行加入 % !Mode:: "TeX:UTF-8"。具体可以参考 ./chapter/ 下的 .tex 文件。
（4）这份模板是本人为了完成自己的博士论文而边写边改的，各种错误在所难免，如果你发现任何任何错误，欢迎来信告知，非常感谢。
（5）若有人愿意继续完善这份模板，并和更多的人分享，是大善事。
